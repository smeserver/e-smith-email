#!/usr/bin/perl -w 

#
# $Id: pseudonyms.pm,v 1.20 2005/04/26 15:39:42 charlieb Exp $
#

package esmith::FormMagick::Panel::pseudonyms;

use strict;
use esmith::AccountsDB;
use esmith::ConfigDB;
use esmith::FormMagick;
use esmith::util;
use File::Basename;
use Exporter;
use Carp;
use URI::Escape;

our @ISA = qw(esmith::FormMagick Exporter);

our @EXPORT = qw( 
    get_prop 
    get_value 
    get_cgi_param
    performCreatePseudonym  
    performModifyPseudonym 
    performRemovePseudonym 
    existing_accounts 
    print_begin_page 
    print_hidden_pseudonym_field
    get_pseudonym_account 
    validate_new_pseudonym_name
    validate_is_pseudonym 
);

our $VERSION = sprintf '%d.%03d', q$Revision: 1.20 $ =~ /: (\d+).(\d+)/;

our $config = esmith::ConfigDB->open();
our $accounts = esmith::AccountsDB->open();


# {{{ header

=pod 

=head1 NAME

esmith::FormMagick::Panels::pseudonyms - useful panel functions

=head1 SYNOPSIS

    use esmith::FormMagick::Panels::pseudonyms;

    my $panel = esmith::FormMagick::Panel::pseudonyms->new();
    $panel->display();

=head1 DESCRIPTION

=cut

# }}}

# {{{ new

=head2 new();

Exactly as for esmith::FormMagick

=begin testing


use_ok('esmith::FormMagick::Panel::pseudonyms');
use vars qw($panel);
ok($panel = esmith::FormMagick::Panel::pseudonyms->new(), "Create panel object");
isa_ok($panel, 'esmith::FormMagick::Panel::pseudonyms');

=end testing

=cut

sub new {
    shift;
    my $self = esmith::FormMagick->new();
    $self->{calling_package} = (caller)[0];
    bless $self;
    return $self;
}

# }}}

=head2 get_cgi_param FM FIELD

Returns the named CGI parameter as a string

=cut

sub get_cgi_param {
    my $fm = shift;
    my $param = shift;

    return ($fm->{'cgi'}->param($param));
}

# {{{ get_prop

=head2 get_prop ITEM PROP

A simple accessor for esmith::ConfigDB::Record::prop

=cut

sub get_prop {
    my $fm = shift;
    my $item = shift;
    my $prop = shift;

    my $record = $config->get($item);
    if ($record) {
        return $record->prop($prop);
    }
    else {
        return '';
    }
}

# }}}

# {{{ get_value 

=head2 get_value ITEM

A simple accessor for esmith::ConfigDB::Record::value

=cut

sub get_value {
    my $fm = shift;
    my $item = shift;

    my $record = $config->get($item);
    if ($record) {
        return $record->value();
    }
    else {
        return '';
    }
}

# }}}

=head1 ACTION

=head2 performCreatePseudonym

Create a new pseudonym

=cut

# {{{ performCreatePseudonym

sub performCreatePseudonym  {
    my $fm = shift;
    my $q = $fm->{'cgi'};
    my $account = $q->param ('account');
    my $pseudonym = $q->param('pseudonym');
    my $msg = "OK";

    $accounts->new_record($pseudonym, { type => 'pseudonym', 
                                     Account => $account} )
        or $msg = "Error occurred while creating pseudonym in database.";

    # Untaint $pseudonym before use in system()
    ($pseudonym) = ($pseudonym =~ /(.+)/);
    system( "/sbin/e-smith/signal-event", "pseudonym-create", "$pseudonym",) 
        == 0 or $msg = "Error occurred while creating pseudonym.";

    if ($msg eq "OK") 
    {
        $q->delete('account');
        $q->delete('pseudonym');
        $fm->success('CREATE_SUCCEEDED');
    }
    else
    {
        $fm->error($msg);
    }
}
# }}}

# {{{ performModifyPseudonym

=head2 performModifyPseudonmy

Modify a pseudonym.

=cut

sub performModifyPseudonym {
    my $fm = shift;
    my $q = $fm->{'cgi'};
    my $msg = "OK";

    my $pseudonym = uri_unescape($q->param ('pseudonym'));
    my $account = $q->param ('account');

    $accounts->get($pseudonym)->set_prop('Account', $account)
        or $msg = "Error occurred while modifying pseudonym in database.";

    # Untaint $pseudonym before use in system()
    ($pseudonym) = ($pseudonym =~ /(.+)/);
    system( "/sbin/e-smith/signal-event", "pseudonym-modify", "$pseudonym",)
        == 0 or $msg = "Error occurred while modifying pseudonym.";

    if ($msg eq "OK")
    {
        $q->delete('account');
        $q->delete('pseudonym');
        $fm->success('MODIFY_SUCCEEDED');
    }
    else
    {
        $fm->error($msg);
    }
}
# }}}

# {{{ performRemovePseudonym

sub performRemovePseudonym {
    my $fm = shift;
    my $q = $fm->{'cgi'};
    my $msg = "OK";

    my $pseudonym = uri_unescape($q->param('pseudonym'));

    unless($fm->validate_is_pseudonym($pseudonym) eq 'OK') {
        $fm->{cgi}->param( -name => 'wherenext', -value => 'InvalidPseudonym' );
        return '';
    }

    #------------------------------------------------------------
    # Make the pseudonym inactive, signal pseudonym-delete event
    # and then delete it
    #------------------------------------------------------------

    my @pseudonyms = $accounts->pseudonyms();

    foreach my $p_rec (@pseudonyms) {
        if ($p_rec->prop("Account") eq $pseudonym) {
            $accounts->get($p_rec->key)->set_prop('type','pseudonym-deleted')
                or $msg = "Error occurred while changing pseudonym type.";
        }
    }

    $accounts->get($pseudonym)->set_prop('type','pseudonym-deleted')
        or $msg = "Error occurred while changing pseudonym type.";

    # Untaint $pseudonym before use in system()
    ($pseudonym) = ($pseudonym =~ /(.+)/);
    system( "/sbin/e-smith/signal-event", "pseudonym-delete", "$pseudonym") == 0
        or $msg = "Error occurred while removing pseudonym.";

    #TODO: is it ->delete or get()->delete
    foreach my $p_rec (@pseudonyms) {
        if ($p_rec->prop("Account") eq $pseudonym) {
            $accounts->get($p_rec->key)->delete()
                or $msg = "Error occurred while deleting pseudonym from database.";
        }
    }

    $accounts->get($pseudonym)->delete()
        or $msg = "Error occurred while deleting pseudonym from database.";

    if ($msg eq "OK")
    {
        $q->delete('pseudonym');
        $fm->success('REMOVE_SUCCEEDED');
    }
    else
    {
        $fm->error($msg);
    }

    return '';
}

# }}} remove pseudonym

# {{{ existing_accounts

=head2 existing_accounts

Return a hash of exisitng system accounts

=cut

sub existing_accounts {
    my $fm = shift;
    my %existingAccounts = ('admin' => "Administrator" );

    foreach my $account ($accounts->get_all) {
        if ($account->prop('type') =~ /(user|group)/) {
            $existingAccounts{$account->key} = $account->key;
        }
        if ($account->prop('type') eq "pseudonym") {
            my $target = $accounts->get($account->prop('Account'));

            unless ($target)
            {
                warn "WARNING: pseudonym (" 
			. $account->key 
			. ") => missing Account(" 
			. $account->prop('Account') 
			. ")\n";
                next;
            }

            $existingAccounts{$account->key} = $account->key 
                unless ($target->prop('type') eq "pseudonym");
        }
    }
    return(\%existingAccounts); 
}

# }}}

# {{{ print_begin_page

=head2 print_begin_page 

Print the initial page of the ofrm

=cut

sub print_begin_page {
    my $fm = shift;
    my $q = $fm->{'cgi'};
    my @emailPseudonyms;
    # Need to untie and re-tie the accounts database to ensure changes
    # are recognised.
    foreach my $account ($accounts->get_all()) {
        my $type = $account->prop('type');
        my $key = $account->key();
        push (@emailPseudonyms, $key) if ($type eq 'pseudonym');
    }
    my $urlprefix = $fm->build_cgi_params($q->param('pseudonym'));    
    print "  <tr>\n    <td colspan='2'>\n";
    print $q->p($q->a({href => "pseudonyms?$urlprefix&wherenext=Create", -class => "button-like"},
                $fm->localise("CLICK_TO_CREATE")));

    my $numPseudonyms = @emailPseudonyms;
    if ($numPseudonyms == 0) {
        print $q->h2($fm->localise('NO_PSEUDONYMS'));
    } else {
        print $q->h2($fm->localise('CURRENT_PSEUDONYMS'));
        print $q->start_table ({-CLASS => "sme-border"});
        print "<tr>      <th class=\"sme-border\">".$fm->localise('PSEUDONYM') ."</th>\n".
            "      <th class=\"sme-border\">".$fm->localise('USER_OR_GROUP') . "</th>\n" .
            "      <th class=\"sme-border\" colspan=\"2\">".$fm->localise('ACTION') . "</th></tr>\n";

        foreach my $pseudonym (sort @emailPseudonyms) {
            my $account = $accounts->get($pseudonym)->prop('Account');

            $account = "Administrator" if ($account eq "admin");
            $account = $fm->localise("EVERYONE") if ($account eq "shared");

            my $removable = $accounts->get($pseudonym)->prop('Removable') || 'yes';
            my $changeable = $accounts->get($pseudonym)->prop('Changeable') || 'yes';

            my $visible = $accounts->get($pseudonym)->prop('Visible');
            $account .= $fm->localise("LOCAL_ONLY")
                if (defined $visible && $visible eq "internal");

            my $urlprefix = $fm->build_cgi_params($pseudonym);
            print "    <tr>\n" .
                "      <td class=\"sme-border\">$pseudonym</td>\n" .
                "      <td class=\"sme-border\">$account</td>\n";
            if ($changeable eq 'no') {
                print "      <td class=\"sme-border\">&nbsp;</td>\n";
            } else {
                print "      <td class=\"sme-border\">".$q->a({href => "pseudonyms?$urlprefix&wherenext=Modify"},$fm->localise("MODIFY"))."</td>\n";
            }
            if ($removable eq 'no') {
                print "      <td class=\"sme-border\">&nbsp;</td>\n";
            } else {
                print "      <td class=\"sme-border\">".$q->a({href => "pseudonyms?$urlprefix&wherenext=Remove"},$fm->localise("REMOVE"))."</td>\n";
            }
            print "</tr>";
        }

        print $q->end_table,"\n";
    }
    print "</td></tr>";
    return '';
}

# }}}

# {{{ get_pseudonym_account

=head2 get_pseudonym_account

Returns the current Account property for this pseudonym

=cut

sub get_pseudonym_account {
    my $fm = shift;
    my $q = $fm->{'cgi'};
    my $pseudonym = $q->param('pseudonym');
    my $account = $accounts->get($pseudonym)->prop('Account');
    if ($account eq "admin") {
        $account = "Administrator";
    } elsif ($account eq "shared") {
        $account = $fm->localise("EVERYONE"); 
    }
    return($account);
}
# }}}

# {{{ validate_new_pseudonym_name 

=head2 validate_new_pseudonym_name FM PSEUDONYM

Returns "OK" if the pseudonym starts with a letter or number and
contains only letters, numbers, . - and _ and isn't taken

Returns  "VALID_PSEUDONYM_NAMES"  if the name contains invalid chars

Returns "NAME_IN_USE" if this pseudonym is taken.

=begin testing

ok(esmith::FormMagick::Panel::pseudonyms::validate_new_pseudonym_name('',"23skidoo") eq 'OK', "23skidoo is a valid pseudonym");
ok(esmith::FormMagick::Panel::pseudonyms::validate_new_pseudonym_name('',"_23skidoo") ne 'OK', "_23skidoo is not  a valid pseudonym");
ok(esmith::FormMagick::Panel::pseudonyms::validate_new_pseudonym_name('',"_23skidoo") eq 'VALID_PSEUDONYM_NAMES', "_23skidoo is  an invalid pseudonym");

=end testing


=cut

sub validate_new_pseudonym_name {
    my $fm = shift;
    my $pseudonym = shift;

    my $acct = $accounts->get($pseudonym);
    if (defined $acct) {
        return('NAME_IN_USE');
    }
    elsif ($pseudonym =~ /@/)
    {
        use esmith::DomainsDB;

        my $ddb = esmith::DomainsDB->open_ro
                or die "Couldn't open DomainsDB\n";

        my ($lhs, $rhs) = split /@/, $pseudonym;

        return ('PSEUDONYM_INVALID_DOMAIN') unless ($ddb->get($rhs));

        return ('PSEUDONYM_INVALID_SAMEACCT')
            if ($lhs eq $fm->{'cgi'}->param('account'));

        return ('OK');
    }
    elsif ($pseudonym !~ /^([a-z0-9][a-z0-9\.\-_!#\?~\$\^\+&`%\/\*]*)$/)
    {
        return('VALID_PSEUDONYM_NAMES');
    }
    else {
        return('OK');
    }
}

# }}}

# {{{ validate_is_pseudonym 

=head2 validate_is_pseudonym FM NAME

returns  "OK" if it is.
returns "NOT_A_PSUEDONYM" if the name in question isn't an existing pseudonym

=cut

sub validate_is_pseudonym {
    my $fm = shift;
    my $pseudonym = shift;
    $pseudonym = $accounts->get($pseudonym);
    return('NOT_A_PSEUDONYM') unless $pseudonym;
    my $type = $pseudonym->prop('type');

    unless (defined $type && ($type eq 'pseudonym') ) {

        return('NOT_A_PSEUDONYM');
    }
    return ('OK');
}

# }}}
                                                                 
=head2 build_cgi_params()                                        
                                                                 
Builds a CGI query string, using various sensible                
defaults and esmith::FormMagick's props_to_query_string() method.
                                                                 
=cut                                                             
                                                                 
sub build_cgi_params {                                           
    my ($fm, $pseudonym) = @_;                                       

    my %props = (                                                
            page       => 0,                                            
            page_stack => "",                                        
            ".id"      => $fm->{cgi}->param('.id') || "",         
            pseudonym  => $pseudonym,                                   
            );                                                           

    return $fm->props_to_query_string(\%props);                  
}                                                                

=head2 print_hidden_pseudonym_field FM

prints a hidden form field containing the current value of the pseudonym
attribute


=cut

sub print_hidden_pseudonym_field {
    my $fm = shift;
    print "<input type='hidden' name='pseudonym' value=\"".uri_escape($fm->{'cgi'}->param('pseudonym'))."\">";
    return '';
}

1;
