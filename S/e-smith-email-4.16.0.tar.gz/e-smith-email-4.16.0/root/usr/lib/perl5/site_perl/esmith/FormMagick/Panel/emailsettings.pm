#!/usr/bin/perl -w 

#
# $Id: emailsettings.pm,v 1.16 2005/09/02 15:14:18 charlieb Exp $
#

package    esmith::FormMagick::Panel::emailsettings;

use strict;
use esmith::ConfigDB;
use esmith::AccountsDB;
use esmith::FormMagick;
use esmith::util;
use File::Basename;
use Exporter;
use Carp;

our @ISA = qw(esmith::FormMagick Exporter);

our @EXPORT = qw( fetchmail_frequencies get_secondary_mail_use_envelope
  change_settings_access change_settings_delivery change_settings_reception
  blank_or_ip_number
  get_current_webmail_status validate_smarthost getExtraParams
  get_current_pop3_access get_current_imap_access get_current_smtp_auth
  get_prop get_value validate_admin_email get_admin_email
);

our $VERSION = sprintf '%d.%03d', q$Revision: 1.16 $ =~ /: (\d+).(\d+)/;

our $db = esmith::ConfigDB->open;
our $pattern_db = esmith::ConfigDB->open("mailpatterns");

# {{{ header

=pod 

=head1 NAME

esmith::FormMagick::Panels::emailsettings - merged email panels

=head1 SYNOPSIS

    use esmith::FormMagick::Panels::emailsettings;

    my $panel = esmith::FormMagick::Panel::emailsettings->new();
    $panel->display();

=head1 DESCRIPTION

=cut

# {{{ new

=head2 new();

Exactly as for esmith::FormMagick

=begin testing


use_ok('esmith::FormMagick::Panel::emailsettings');
use vars qw($panel);
ok($panel = esmith::FormMagick::Panel::emailsettings->new(), "Create panel object");
isa_ok($panel, 'esmith::FormMagick::Panel::emailsettings');

=end testing

=cut

sub new {
    shift;
    my $self = esmith::FormMagick->new();
    $self->{calling_package} = (caller)[0];
    bless $self;
    return $self;
}

# }}}

=head2 get_prop ITEM PROP

A simple accessor for esmith::ConfigDB::Record::prop

=cut

sub get_prop 
{
    my ($fm, $item, $prop, $default) = @_;

    return $db->get_prop($item, $prop) || $default;
}

=head2 get_value ITEM

A simple accessor for esmith::ConfigDB::Record::value

=cut

sub get_value 
{
    my $fm   = shift;
    my $item = shift;

    return $db->get_value($item) || '';
}

=head2 get_emailunknownuser_options

Return a hash of existing system accounts and returntosender

=cut

sub get_emailunknownuser_options {
    my $fm = shift;
    my $accounts = esmith::AccountsDB->open_ro();
    my %existingAccounts = ('admin' => $fm->localise("FORWARD_TO_ADMIN"), 
            'returntosender' => $fm->localise("RETURN_TO_SENDER") );

    foreach my $account ($accounts->get_all) {
        next if $account->key eq 'everyone';
        if ($account->prop('type') =~ /(user|group|pseudonym)/) {
            $existingAccounts{$account->key} = $fm->localise("FORWARD_TO") . " " . $account->key;
        }
    }
    return(\%existingAccounts); 
}

sub get_emailunknownuser_status
{
    my ($fm, $localise) = @_;

    my $options = $fm->get_emailunknownuser_options();

    my $val = $db->get_value('EmailUnknownUser') || "returntosender";

    return $localise ? $fm->localise($options->{$val}) : $val;
}

=head2 get_secondary_mail_use_envelope

Returns on or off, based on whether or not the fetchmail "SecondaryMailEnvelope" 
property is set.

=cut

sub get_secondary_mail_use_envelope {

    my $use_envelope = $db->get_prop('fetchmail', 'SecondaryMailEnvelope');
    if ( defined $use_envelope ) {
        return ('on');
    }
    else {
        return ('off');
    }
}

=head2 fetchmail_frequencies

  Returns a string of a hash of frequencies to have fetchmail check mail

=cut

sub fetchmail_frequencies {

    my %params = (
        'never'      => 'NEVER',
        'every5min'  => 'EVERY5MIN',
        'every15min' => 'EVERY15MIN',
        'every30min' => 'EVERY30MIN',
        'everyhour'  => 'EVERYHOUR',
        'every2hrs'  => 'EVERY2HRS'
    );

    return ( \%params );
}

=head1 ACTION

=head2 change_settings_reception

	If everything has been validated, properly, go ahead and set the new settings

=cut

sub change_settings_reception
{
    my ($fm) = @_;
    my $q = $fm->{'cgi'};

    my $FetchmailMethod = ( $q->param('FetchmailMethod') || 'standard' );

    my $FetchmailFreqOffice = ( $q->param('FreqOffice') || 'every15min' );

    my $FetchmailFreqOutside = ( $q->param('FreqOutside')   || 'everyhour' );
    my $FetchmailFreqWeekend = ( $q->param('FreqWeekend')   || 'everyhour' );
    my $SpecifyHeader        = ( $q->param('SpecifyHeader') || 'off' );

    my $fetchmail = $db->get('fetchmail') || $db->new_record( "fetchmail", 
			{ type => "service", status => "disabled" } );

    if ( $FetchmailMethod eq 'standard' ) {
        $fetchmail->set_prop( 'status', 'disabled' );
        $fetchmail->set_prop( 'Method', $FetchmailMethod );
    }
    else {
        $fetchmail->set_prop( 'status', 'enabled' );
        $fetchmail->set_prop( 'Method', $FetchmailMethod );
        $fetchmail->set_prop( 'SecondaryMailServer', 
	    $q->param('SecondaryMailServer') )
	    unless ( $q->param('SecondaryMailServer') eq '' );

        $fetchmail->set_prop('FreqOffice',  $FetchmailFreqOffice );
        $fetchmail->set_prop('FreqOutside', $FetchmailFreqOutside );
        $fetchmail->set_prop('FreqWeekend', $FetchmailFreqWeekend );
        $fetchmail->set_prop('SecondaryMailAccount',
	    $q->param('SecondaryMailAccount') )
	    unless ( $q->param('SecondaryMailAccount') eq '' );

        $fetchmail->set_prop( 'SecondaryMailPassword',
	    $q->param('SecondaryMailPassword') )
	    unless ( $q->param('SecondaryMailPassword') eq '' );

        if ( $SpecifyHeader eq 'on' ) {
            $fetchmail->merge_props(
                'SecondaryMailEnvelope' => $q->param('SecondaryMailEnvelope') );
        }
        else {
            $fetchmail->delete_prop('SecondaryMailEnvelope');
        }
    }

    my $smtpAuth = ($q->param('SMTPAuth') || 'disabled');
    if ($smtpAuth eq 'public') {
        $db->set_prop("smtpd", "Authentication", "enabled" );
        $db->set_prop("ssmtpd", "Authentication", "enabled" );
    } elsif ($smtpAuth eq 'publicSSL') {
        $db->set_prop("smtpd", "Authentication", "disabled" );
        $db->set_prop("ssmtpd", "Authentication", "enabled" );
    } else {
        $db->set_prop("smtpd", "Authentication", "disabled" );
        $db->set_prop("ssmtpd", "Authentication", "disabled" );
    }

    unless ( system( "/sbin/e-smith/signal-event", "email-update" ) == 0 )
    {
	$fm->error('ERROR_UPDATING');
	return undef;
    }
    $fm->success('SUCCESS');
}

sub change_settings_delivery
{
    my ($fm) = @_;
    my $q = $fm->{'cgi'};

    my $EmailUnknownUser = ($q->param('EmailUnknownUser') || 'returntosender');

    $db->set_value('SMTPSmartHost', $q->param('SMTPSmartHost'));
    $db->set_value('DelegateMailServer', $q->param('DelegateMailServer'));
    $db->set_value('EmailUnknownUser', $EmailUnknownUser);
    my $accounts = esmith::AccountsDB->open;
    my $admin_email = $q->param('AdminEmail');
    my $admin = $accounts->get('admin');
    if ($admin_email)
    {
	$admin->merge_props(
		EmailForward => 'forward',
		ForwardAddress => $admin_email,
		);
    }
    else
    {
	$admin->merge_props(
		EmailForward => 'local',
		ForwardAddress => '',
		);
    }

    my $proxy = $db->get('smtp-auth-proxy');
    my %props = $proxy->props;

    for ( qw(Userid Passwd status) )
    {
        $props{$_} = $q->param("SMTPAUTHPROXY_$_");
    }

    $proxy->merge_props(%props);

    unless ( system( "/sbin/e-smith/signal-event", "email-update" ) == 0 )
    {
	$fm->error('ERROR_UPDATING');
	return undef;
    }
    $fm->success('SUCCESS');
}

sub change_settings_access
{
    my ($fm) = @_;
    my $q = $fm->{'cgi'};

    my $pop3Access = ($q->param('POPAccess') || 'private');
    if ($pop3Access eq 'disabled') {
        $db->set_prop('pop3', "status", "disabled" );
        $db->set_prop('pop3s', "status", "disabled" );
    } else {
        $db->set_prop('pop3', "status", "enabled" );
        $db->set_prop('pop3s', "status", "enabled" );
    }
    if ($pop3Access eq 'public') {
        $db->set_prop('pop3', "access", "public" );
        $db->set_prop('pop3s', "access", "public" );
    } elsif ($pop3Access eq 'publicSSL') {
        $db->set_prop('pop3', "access", "private" );
        $db->set_prop('pop3s', "access", "public" );
    } else {
        $db->set_prop('pop3', "access", "private" );
        $db->set_prop('pop3s', "access", "private" );
    }

    my $imapAccess = ($q->param('IMAPAccess') || 'private');
    if ($imapAccess eq 'disabled') {
        $db->set_prop('imap', "status", "disabled" );
        $db->set_prop('imaps', "status", "disabled" );
    } else {
        $db->set_prop('imap', "status", "enabled" );
        $db->set_prop('imaps', "status", "enabled" );
    }
    if ($imapAccess eq 'public') {
        $db->set_prop('imap', "access", "public" );
        $db->set_prop('imaps', "access", "public" );
    } elsif ($imapAccess eq 'publicSSL') {
        $db->set_prop('imap', "access", "private" );
        $db->set_prop('imaps', "access", "public" );
    } else {
        $db->set_prop('imap', "access", "private" );
        $db->set_prop('imaps', "access", "private" );
    }

    #------------------------------------------------------------
    # Set webmail state in configuration database, and access
    # type for SSL
    # PHP and MySQL should always be on, and are enabled by default
    # We don't do anything with them here.
    #------------------------------------------------------------

    my $webmail = ($q->param('WebMail') || 'disabled');
    if ( $webmail eq "enabled" ) {
      $db->set_prop('php', "status", $webmail );
      $db->set_prop('mysqld',"status", $webmail );
      $db->set_prop('imp',"status", $webmail );
      $db->set_prop('horde', "status", $webmail );
      $db->set_prop('imp',"access", "full" );
      $db->set_prop('horde',"access", "full" );
    }
    elsif ( $webmail eq "enabledSSL" ) {
      $db->set_prop('php',"status", "enabled" );
      $db->set_prop('mysqld',"status", "enabled" );
      $db->set_prop('imp',"status", 'enabled' );
      $db->set_prop('horde',"status", 'enabled' );
      $db->set_prop('imp',"access", "SSL" );
      $db->set_prop('horde',"access", "SSL" );
    }
    else {
      $db->set_prop('imp',"status", 'disabled' );
      $db->set_prop('horde',"status", 'disabled' );
    }
    
    unless ( system( "/sbin/e-smith/signal-event", "email-update" ) == 0 )
    {
	$fm->error('ERROR_UPDATING');
	return undef;
    }

    $fm->success('SUCCESS');
}

sub change_settings_filtering
{
    my ($fm) = @_;
    my $q = $fm->{'cgi'};

    my $virus_status = ( $q->param('VirusStatus') || 'disabled' );
    $db->set_prop("smtpd", 'VirusScan', $virus_status);

    for my $param ( qw(
			status 
			Sensitivity
			TagLevel
			RejectLevel
			SortSpam 
			SubjectTag) )
    {
	$db->set_prop('spamassassin', $param, $q->param("Spam$param"));
    }

    my $patterns_status = $fm->adjust_patterns() ? 'enabled' : 'disabled';
    $db->set_prop("smtpd", 'PatternsScan', $patterns_status);

    unless ( system( "/sbin/e-smith/signal-event", "email-update" ) == 0 )
    {
	$fm->error('ERROR_UPDATING');
	return undef;
    }

    $fm->success('SUCCESS');
}

=pod

=head2 blank_or_ip_number()

Validator. Checks that the input is either blank or an IP number. This is a
wrapper around CGI::FormMagick::Validator::Network::ip_number().

=for testing
is($panel->blank_or_ip_number(),'OK','blank_or_ip_number');
is($panel->blank_or_ip_number(''),'OK','  .. blank is valid');
is($panel->blank_or_ip_number('1.2.3.4'),'OK','  .. "1.2.3.4" is valid');
isnt($panel->blank_or_ip_number('bad'),'OK','  .. "bad" is invalid');

=cut

sub blank_or_ip_number
{
    my ($self,$value) = @_;

    return 'OK' unless (defined $value); # undef is blank
    return 'OK' if ($value =~ /^$/); # blank is blank
    return $self->call_fm_validation("ip_number",$value,''); # otherwise, validate the input
}

=pod

=head2 get_retrieval_options

Returns the options values for the retrieval mode select box. In private
S&G mode, we only support multidrop.

=cut
sub get_retrieval_options
{
    return $db->get("SystemMode")->value eq "servergateway-private"
         ? {'multidrop' => 'MULTIDROP'}
         : {'standard'  => 'STANDARD',
            'etrn'      => 'ETRN',
            'multidrop' => 'MULTIDROP'};
}

sub get_current_retrieval
{
    my ($fm, $localise) = @_;

    my $method = $db->get_prop('fetchmail', 'Method');

    my $options = get_retrieval_options();

    return $localise ? $fm->localise($options->{$method}) : $method;
}

=head2 get_current_pop3_access

returns "private", "public" or "publicSSL", depending on whether
the various components of the pop3 subsystem are currently enabled

=cut

sub get_current_pop3_access {
    my ($fm, $localise) = @_;

    my $pop3Status = $db->get_prop('pop3', 'status') || 'enabled';
    my $pop3Access = $db->get_prop('pop3', 'access') || 'private';

    my $pop3sStatus = $db->get_prop('pop3s', 'status') || 'enabled';
    my $pop3sAccess = $db->get_prop('pop3s', 'access') || 'private';

    my $options = get_pop_options();

    if ($pop3Status ne 'enabled' && $pop3sStatus ne 'enabled')
    {
        return $localise ? $fm->localise($options->{disabled}) : 'disabled';
    }
    elsif ($pop3Status eq 'enabled' && $pop3Access eq 'public')
    {
        return $localise ? $fm->localise($options->{public}) : 'public';
    }
    elsif ($pop3sStatus eq 'enabled' && $pop3sAccess eq 'public')
    {
        return $localise ? $fm->localise($options->{publicSSL}) : 'publicSSL';
    }
    return $localise ? $fm->localise($options->{private}) : 'private';
}

=head2 get_current_imap_access

returns "private", "public" or "publicSSL", depending on whether
the various components of the imap subsystem are currently enabled

=cut

sub get_current_imap_access {
    my ($fm, $localise) = @_;

    my $imapStatus = $db->get_prop('imap', 'status') || 'enabled';
    my $imapAccess = $db->get_prop('imap', 'access') || 'private';

    my $imapsStatus = $db->get_prop('imaps', 'status') || 'enabled';
    my $imapsAccess = $db->get_prop('imaps', 'access') || 'private';

    my $options = get_imap_options();

    if ($imapStatus ne 'enabled' && $imapsStatus ne 'enabled')
    {
        return $localise ? $fm->localise($options->{disabled}) : 'disabled';
    }
    if ($imapStatus eq 'enabled' && $imapAccess eq 'public')
    {
        return $localise ? $fm->localise($options->{public}) : 'public';
    }
    elsif ($imapsStatus eq 'enabled' && $imapsAccess eq 'public')
    {
        return $localise ? $fm->localise($options->{publicSSL}) : 'publicSSL';
    }
    return $localise ? $fm->localise($options->{private}) : 'private';
}

=head2 get_current_smtp_auth

returns "disabled", "public" or "publicSSL", depending on whether
the various components of the smtp auth subsystem are currently enabled

=cut

sub get_current_smtp_auth {

    my ($fm, $localise) = @_;

    my $smtpStatus = $db->get_prop('smtpd', 'status') || 'enabled';
    my $smtpAuth = $db->get_prop('smtpd', 'Authentication') || 'disabled';

    my $smtpsStatus = $db->get_prop('ssmtpd', 'status') || 'enabled';
    my $smtpsAuth = $db->get_prop('ssmtpd', 'Authentication') || 'disabled';

    my $options = get_smtp_auth_options();

    if ($smtpStatus eq 'enabled' && $smtpAuth eq 'enabled')
    {
        return $localise ? $fm->localise($options->{public}) : 'public';
    }
    elsif ($smtpsStatus eq 'enabled' && $smtpsAuth eq 'enabled')
    {
        return $localise ? $fm->localise($options->{publicSSL}) : 'publicSSL';
    }
    return $localise ? $fm->localise($options->{disabled}) : 'disabled';
}

=head2 get_current_webmail_status

returns "disabled", "enabled" or "enabledSSL", depending on whether
the various components of the webmail subsystem are currently enabled

=cut

sub get_current_webmail_status {

  my ($fm, $localise) = @_;

  # determine status of webmail
  my $WebmailStatus = "disabled";

  my $IMPStatus = $db->get_prop('imp', 'status') || 'disabled';
  my $SSLonly = $db->get_prop('imp', 'access') || 'disabled';

  my $HordeStatus = $db->get_prop('horde', 'status') || 'disabled';

  my $MysqlStatus = $db->get_prop('mysqld', 'status') || 'disabled';

  my $PHPStatus = $db->get_prop('php', 'status') || 'disabled';

  # all four components must be on for webmail to be working
  if ( ( $IMPStatus eq "enabled" )
       && ( $HordeStatus eq "enabled" )
       && ( $MysqlStatus eq "enabled" )
       && ( $PHPStatus eq "enabled" ) )
    {
      $WebmailStatus = ( $SSLonly eq "SSL" ) ? "enabledSSL" : "enabled";
    }

  my $options = get_webmail_options();

  return $localise ? $fm->localise($options->{$WebmailStatus}) 
                   : $WebmailStatus;
  
}

# {{{ Validation

=head1 VALIDATION ROUTINES

=head2 validate_smarthost

Returns OK if smarthost is valid. 

Returns SMARTHOST_VALIDATION_ERROR and pushes us back to the first page otherwise.

=begin testing

ok(validate_smarthost('','foo.com') eq 'OK', 'foo.com is a valid host');
ok(validate_smarthost('','') eq 'OK', 'undef is a valid host');
ok(validate_smarthost('','fleeble') eq 'INVALID_SMARTHOST', '"fleeble" is not a valid host');


=end testing

=cut

sub validate_smarthost {
    my $fm = shift;
    my $smarthost = shift;
    
    return ('OK') if ( $smarthost =~ /^(\S+\.\S+)$/ );

    return ('OK') if ( $smarthost eq '' );
    
    return "INVALID_SMARTHOST";
    
}

=head2 validate_admin_email

This method validates the admin email address.

=cut

sub validate_admin_email
{
    my $self = shift;
    my $q = $self->{cgi};

    my $admin_email = $q->param('AdminEmail') || '';
    $admin_email =~ s/^\s+|\s+$//g;

    my $response = $self->email_simple($admin_email);
    if (($response eq 'OK') or ($admin_email eq ''))
    {
        return 'OK';
    }
    else
    {
        return 'UNACCEPTABLE_CHARS';
    }
}

=head2 get_admin_email

=cut

sub get_admin_email
{
    my $self = shift;
    my $accounts = esmith::AccountsDB->open_ro();
    my $admin = $accounts->get('admin');
    return ($admin->prop('EmailForward') eq 'forward') ?
	$admin->prop('ForwardAddress') : '';
}

=pod

=head2 getExtraParams

Returns some extra values for localise() that are used to evaluate embedded
vars in localised text.

=cut

sub getExtraParams
{
	my $conf = esmith::ConfigDB->open();
	my $systemName = $conf->get('SystemName');
	my $domainName = $conf->get('DomainName');

	$systemName = $systemName->value if ($systemName);
	$domainName = $domainName->value if ($domainName);

	return (FQDN => join('.', ($systemName, $domainName)));
}

sub get_patterns_status
{
    my ($self, $localise) = @_;

    my $status = $db->get_prop("smtpd", 'PatternsScan') || 'disabled';

    return $localise ? $self->localise_status($status) : $status;
}

sub adjust_patterns
{
    my $fm = shift;
    my $q = $fm->{'cgi'};

    my @selected;
    
    push @selected, $q->param('BlockExecutableContent');

    foreach my $pattern ( $pattern_db->get_all_by_prop( type => "pattern") )
    {
        my $status = (grep $pattern->key eq $_, @selected) ? 'enabled' 
                                                           : 'disabled';
        $pattern->set_prop('Status', $status);
    }

    $pattern_db->reload;

    return scalar @selected;
}

sub get_patterns_options
{
    my $self = shift;

    my %options;

    foreach my $pattern ( $pattern_db->get_all_by_prop( type => "pattern" ) )
    {
        my %props = $pattern->props;

        $options{$pattern->key} = $props{'Description'};
    }

    return \%options;
}

sub get_patterns_current_options
{
    my $self = shift;

    my @selected;

    foreach my $pattern ( $pattern_db->get_all_by_prop( type => "pattern" ) )
    {
        my %props = $pattern->props;

        push @selected, $pattern->key if ($props{'Status'} eq 'enabled');
    }

    return \@selected;
}

sub get_smtp_auth_options
{
    my %options = ( disabled => 'DISABLED', publicSSL  => 'SECURE_SMTP' );

    my $cleartext = $db->get_prop('smtpd', 'Authentication') || 'disabled';

    $options{public} = 'INSECURE_SMTP' if ($cleartext eq 'enabled');

    \%options;
}

sub get_pop_options
{
    my %options = (
	disabled => 'DISABLED',
	private => 'PRIVATE_POP3',
	publicSSL  => 'SECURE_POP3'
    );

    my $access = $db->get_prop('pop3', 'access') || 'private';

    $options{public} = 'INSECURE_POP3' if ($access eq 'public');

    \%options;
}

sub get_imap_options
{
    my %options = (
	disabled => 'DISABLED',
	private => 'PRIVATE_IMAP',
	publicSSL  => 'SECURE_IMAP'
    );

    my $access = $db->get_prop('imap', 'access') || 'private';

    $options{public} = 'INSECURE_IMAP' if ($access eq 'public');

    \%options;
}

sub get_webmail_options
{
    my %options = ( disabled   => 'DISABLED', 
		enabledSSL => 'ENABLED_SECURE_ONLY' );

    my $access = $db->get_prop('imp', 'access') || 'SSL';

    $options{public} = 'ENABLED_BOTH' if ($access eq 'full');

    \%options;
}

sub get_virus_status
{
    my ($self, $localise) = @_;

    my $status = $db->get_prop("smtpd", 'VirusScan') || 'disabled';

    return $localise ? $self->localise_status($status) : $status;
}

sub get_spam_status
{
    my ($self, $localise) = @_;

    my $status = $db->get_prop('spamassassin', 'status') || 'disabled';

    return $localise ? $self->localise_status($status) : $status;
}

sub get_spam_level_options
{
    return [ 0..20 ];
}

sub display_multidrop
{
    my $status = $db->get_prop('fetchmail', 'status') || 'disabled';

    # XXX FIXME - WIP 
    # Only display ETRN/multidrop settings if relevant
    # To do this, we need an "Show ETRN/multidrop settings" button
    # in standard mode.

    # return ($status eq 'enabled');
    return 1;	
}

sub localise_status
{
    my ($self, $status) = @_;

    return $self->localise($status eq 'enabled' ? 'ENABLED' : 'DISABLED');
}

sub nonblank_if_smtpauth
{
    my ($fm, $value) = @_;

    my $q = $fm->{'cgi'};

    return "OK" unless ($q->param("SMTPAUTHPROXY_status") eq 'enabled');

    return ($value =~ /\S+/) ? "OK" : "VALIDATION_SMTPAUTH_NONBLANK";
}

sub display_access_page
{
    for ( qw(imp imap pop3) )
    {
        return 1 if $db->get_prop($_, 'type');
    }

    return 0;
}

1;
