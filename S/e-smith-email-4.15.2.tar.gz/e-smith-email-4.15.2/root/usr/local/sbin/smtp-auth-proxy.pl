#!/usr/bin/perl -w -T
 
package esmith::SMTPAuthProxy;
 
use strict;
use vars qw(@ISA);
use Net::Server::Fork;
use Net::SMTP;
use esmith::ConfigDB;
 
@ISA = qw(Net::Server::Fork);

my $config = esmith::ConfigDB->open_ro;
 
esmith::SMTPAuthProxy->run(
    max_servers => 4,
    proto => 'tcp',
    user => 'nobody',
    group => 'nobody',
    host => 'localhost',
    port => 26);
exit;
 
### over-ridden subs below
 
sub process_request
{
    my $self = shift;
    my $smtp = $self->{smtp};
    my $kidpid;
 
    die "can't fork: $!" unless defined ($kidpid = fork());
    if ($kidpid)
    {
        my $line;
        while (defined ($line = <STDIN>))
        {
            print $smtp $line;
        }
        kill ("TERM" => $kidpid);
    }
    else
    {
        my $line;
        while (defined ($line = <$smtp>))
        {
            print STDOUT $line;
        }
    }
}
 
sub post_accept_hook
{
    my $self = shift;

    my $smtp_proxy_rec = $config->get('smtp-auth-proxy');
    unless ($smtp_proxy_rec)
    {
        warn "There is no smtp-auth-proxy record!\n";
        return;
    }
    my $smarthost = $config->get_value('SMTPSmartHost');
    my $me = $config->get_value('SystemName') . '.' .
             $config->get_value('DomainName');
    my $name = $smtp_proxy_rec->prop('Userid');
    my $pass = $smtp_proxy_rec->prop('Passwd');
    my $debug = (($smtp_proxy_rec->prop('Debug') || 'disabled') eq 'enabled')
                ? 1 : 0;
    unless ($smarthost && $me && $name && $pass)
    {
        warn "Insufficient configuration for smtp-auth-proxy!\n";
        return;
    }
 
    my $smtp = Net::SMTP->new($smarthost,
                            Hello => $me,
                            Debug => $debug
                        );
    if ($smtp->supports("AUTH"))
    {
        unless ($smtp->auth($name, $pass))
        {
            print "451 Could not auth to mail server\n";
            warn "SMTP authentication with ISP server failed\n";
            $smtp->quit;
            exit;
        }
    }
    else
    {
        warn "Upstream SMTP server does not support authentication\n";
    }
    $self->{smtp} = $smtp;
    print "220 ", $smtp->banner;
}
 
1;
