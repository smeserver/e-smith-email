#!/usr/bin/perl -w 

#
# $Id: emailsettings.pm,v 1.5 2005/03/14 23:19:34 charlieb Exp $
#

package    esmith::FormMagick::Panel::emailsettings;

use strict;
use esmith::ConfigDB;
use esmith::AccountsDB;
use esmith::FormMagick;
use esmith::util;
use File::Basename;
use Exporter;
use Carp;

our @ISA = qw(esmith::FormMagick Exporter);

our @EXPORT = qw( fetchmail_frequencies get_secondary_mail_use_envelope
  change_settings blank_or_ip_number get_options existing_accounts_and_return
  get_current_webmail_status validate_smarthost getExtraParams
  get_current_pop3_access get_current_imap_access get_current_smtp_auth
  get_prop get_value show_mailpatterns_section validate_admin_email
);

our $VERSION = sprintf '%d.%03d', q$Revision: 1.5 $ =~ /: (\d+).(\d+)/;

our $db = esmith::ConfigDB->open;
our $pattern_db = esmith::ConfigDB->open("/home/e-smith/mailpatterns");

# {{{ header

=pod 

=head1 NAME

esmith::FormMagick::Panels::emailsettings - merged email panels

=head1 SYNOPSIS

    use esmith::FormMagick::Panels::emailsettings;

    my $panel = esmith::FormMagick::Panel::emailsettings->new();
    $panel->display();

=head1 DESCRIPTION

=cut

# {{{ new

=head2 new();

Exactly as for esmith::FormMagick

=begin testing


use_ok('esmith::FormMagick::Panel::emailsettings');
use vars qw($panel);
ok($panel = esmith::FormMagick::Panel::emailsettings->new(), "Create panel object");
isa_ok($panel, 'esmith::FormMagick::Panel::emailsettings');

=end testing

=cut

sub new {
    shift;
    my $self = esmith::FormMagick->new();
    $self->{calling_package} = (caller)[0];
    bless $self;
    return $self;
}

# }}}

=head2 get_prop ITEM PROP

A simple accessor for esmith::ConfigDB::Record::prop

=cut

sub get_prop 
{
    my $fm   = shift;
    my $item = shift;
    my $prop = shift;

    return $db->get_prop($item, $prop) || '';
}

=head2 get_value ITEM

A simple accessor for esmith::ConfigDB::Record::value

=cut

sub get_value 
{
    my $fm   = shift;
    my $item = shift;

    return $db->get_value($item) || '';
}

=head2 existing_accounts_and_return

Return a hash of existing system accounts and returntosender

=cut

sub existing_accounts_and_return {
    my $fm = shift;
    my $accounts = esmith::AccountsDB->open();
    my %existingAccounts = ('admin' => $fm->localise("FORWARD_TO_ADMIN"), 
            'returntosender' => $fm->localise("RETURN_TO_SENDER") );

    foreach my $account ($accounts->get_all) {
        next if $account->key eq 'everyone';
        if ($account->prop('type') =~ /(user|group|pseudonym)/) {
            $existingAccounts{$account->key} = $fm->localise("FORWARD_TO") . " " . $account->key;
        }
    }
    return(\%existingAccounts); 
}

=head2 get_secondary_mail_use_envelope

Returns on or off, based on whether or not the fetchmail "SecondaryMailEnvelope" 
property is set.

=cut

sub get_secondary_mail_use_envelope {

    my $use_envelope = $db->get('fetchmail')->prop('SecondaryMailEnvelope');
    if ( defined $use_envelope ) {
        return ('on');
    }
    else {
        return ('off');
    }
}

=head2 fetchmail_frequencies

  Returns a string of a hash of frequencies to have fetchmail check mail

=cut

sub fetchmail_frequencies {

    my %params = (
        'never'      => 'NEVER',
        'every5min'  => 'EVERY5MIN',
        'every15min' => 'EVERY15MIN',
        'every30min' => 'EVERY30MIN',
        'everyhour'  => 'EVERYHOUR',
        'every2hrs'  => 'EVERY2HRS'
    );

    return ( \%params );
}

=head1 ACTION

=head2 change_settings

	If everything has been validated, properly, go ahead and set the new settings

=cut

sub change_settings {
    my ($fm) = @_;

    my %conf;

    my $q = $fm->{'cgi'};

    my $FetchmailMethod = ( $q->param('FetchmailMethod') || 'standard' );

    my $FetchmailFreqOffice = ( $q->param('FreqOffice') || 'every15min' );

    my $FetchmailFreqOutside = ( $q->param('FreqOutside')   || 'everyhour' );
    my $FetchmailFreqWeekend = ( $q->param('FreqWeekend')   || 'everyhour' );
    my $SpecifyHeader        = ( $q->param('SpecifyHeader') || 'off' );
    my $DelegateMailServer =  $q->param('DelegateMailServer');

    #------------------------------------------------------------
    # Looks good; go ahead and save the settings.
    #------------------------------------------------------------

    if ($DelegateMailServer)
    {
        my $d = $db->get('DelegateMailServer') ||
		    $db->new_record('DelegateMailServer');
        $d->set_value($DelegateMailServer);
    }
    else
    {
	my $d = $db->get('DelegateMailServer');
	$d->delete() if $d;
    }

    $db->get('fetchmail')->set_prop( "service", { status => "disabled" } )
      unless ( $db->get("fetchmail") );

    if ( $FetchmailMethod eq 'standard' ) {
        $db->get('fetchmail')->set_prop( 'status', 'disabled' );
        $db->get('fetchmail')->set_prop( 'Method', $FetchmailMethod );
    }
    else {
        $db->get('fetchmail')->set_prop( 'status', 'enabled' );
        $db->get('fetchmail')->set_prop( 'Method', $FetchmailMethod );
        $db->get('fetchmail')
          ->set_prop( 'SecondaryMailServer', $q->param('SecondaryMailServer') )
          unless ( $q->param('SecondaryMailServer') eq '' );

        $db->get('fetchmail')->set_prop( 'FreqOffice',  $FetchmailFreqOffice );
        $db->get('fetchmail')->set_prop( 'FreqOutside', $FetchmailFreqOutside );
        $db->get('fetchmail')->set_prop( 'FreqWeekend', $FetchmailFreqWeekend );
        $db->get('fetchmail')
          ->set_prop( 'SecondaryMailAccount',
            $q->param('SecondaryMailAccount') )
          unless ( $q->param('SecondaryMailAccount') eq '' );

        $db->get('fetchmail')
          ->set_prop( 'SecondaryMailPassword',
            $q->param('SecondaryMailPassword') )
          unless ( $q->param('SecondaryMailPassword') eq '' );

        if ( $SpecifyHeader eq 'on' ) {
            $db->get('fetchmail')
              ->merge_props(
                'SecondaryMailEnvelope' => $q->param('SecondaryMailEnvelope') );
        }
        else {
            $db->get("fetchmail")->delete_prop('SecondaryMailEnvelope');
        }
    }

    my $EmailUnknownUser = ($q->param('EmailUnknownUser') || 'returntosender');


    $db->get('SMTPSmartHost')->set_value($q->param('SMTPSmartHost'));
    $db->get('EmailUnknownUser')->set_value($EmailUnknownUser);
    $db->get('AdminEmail')->set_value($q->param('AdminEmail'));

    my $pop3Access = ($q->param('POPAccess') || 'private');
    if ($pop3Access eq 'public') {
        $db->get('popd')->set_prop("access", "public" );
        $db->get('pop3s')->set_prop("access", "public" );
    } elsif ($pop3Access eq 'publicSSL') {
        $db->get('popd')->set_prop("access", "private" );
        $db->get('pop3s')->set_prop("access", "public" );
    } else {
        $db->get('popd')->set_prop("access", "private" );
        $db->get('pop3s')->set_prop("access", "private" );
    }

    my $imapAccess = ($q->param('IMAPAccess') || 'private');
    if ($imapAccess eq 'public') {
        $db->get('imap')->set_prop("access", "public" );
        $db->get('imaps')->set_prop("access", "public" );
    } elsif ($imapAccess eq 'publicSSL') {
        $db->get('imap')->set_prop("access", "private" );
        $db->get('imaps')->set_prop("access", "public" );
    } else {
        $db->get('imap')->set_prop("access", "private" );
        $db->get('imaps')->set_prop("access", "private" );
    }

    my $smtpAuth = ($q->param('SMTPAuth') || 'disabled');
    if ($smtpAuth eq 'public') {
        $db->get('smtpfront-qmail')->set_prop("authentication", "enabled" );
        $db->get('ssmtpfront-qmail')->set_prop("authentication", "enabled" );
    } elsif ($smtpAuth eq 'publicSSL') {
        $db->get('smtpfront-qmail')->set_prop("authentication", "disabled" );
        $db->get('ssmtpfront-qmail')->set_prop("authentication", "enabled" );
    } else {
        $db->get('smtpfront-qmail')->set_prop("authentication", "disabled" );
        $db->get('ssmtpfront-qmail')->set_prop("authentication", "disabled" );
    }

    $fm->adjust_patterns();

    #------------------------------------------------------------
    # Set webmail state in configuration database, and access
    # type for SSL
    # PHP and MySQL should always be on, and are enabled by default
    # We don't do anything with them here.
    #------------------------------------------------------------

    my $webmail = ($q->param('WebMail') || 'disabled');
    if ( $webmail eq "enabled" ) {
      $db->get('php')->set_prop("status", $webmail );
      $db->get('mysqld')->set_prop("status", $webmail );
      $db->get('imp')->set_prop("status", $webmail );
      $db->get('horde')->set_prop(  "status", $webmail );
      $db->get('imp')->set_prop("access", "full" );
      $db->get('horde')->set_prop("access", "full" );
    }
    elsif ( $webmail eq "enabledSSL" ) {
      $db->get('php')->set_prop("status", "enabled" );
      $db->get('mysqld')->set_prop("status", "enabled" );
      $db->get('imp')->set_prop("status", 'enabled' );
      $db->get('horde')->set_prop("status", 'enabled' );
      $db->get('imp')->set_prop("access", "SSL" );
      $db->get('horde')->set_prop("access", "SSL" );
    }
    else {
      $db->get('imp')->set_prop("status", 'disabled' );
      $db->get('horde')->set_prop( "status", 'disabled' );
    }
    
    unless ( system( "/sbin/e-smith/signal-event", "email-update" ) == 0 )
    {
	$fm->error('ERROR_UPDATING');
	return undef;
    }

    $fm->success('SUCCESS');
}

=pod

=head2 blank_or_ip_number()

Validator. Checks that the input is either blank or an IP number. This is a
wrapper around CGI::FormMagick::Validator::Network::ip_number().

=for testing
is($panel->blank_or_ip_number(),'OK','blank_or_ip_number');
is($panel->blank_or_ip_number(''),'OK','  .. blank is valid');
is($panel->blank_or_ip_number('1.2.3.4'),'OK','  .. "1.2.3.4" is valid');
isnt($panel->blank_or_ip_number('bad'),'OK','  .. "bad" is invalid');

=cut

sub blank_or_ip_number
{
    my ($self,$value) = @_;

    return 'OK' unless (defined $value); # undef is blank
    return 'OK' if ($value =~ /^$/); # blank is blank
    return $self->call_fm_validation("ip_number",$value,''); # otherwise, validate the input
}

=pod

=head2 get_options

Returns the options values for the retrieval mode select box. In private
S&G mode, we only support multidrop.

=cut
sub get_options
{
    return $db->get("SystemMode")->value eq "servergateway-private"
         ? {'multidrop' => 'MULTIDROP'}
         : {'standard'  => 'STANDARD',
            'etrn'      => 'ETRN',
            'multidrop' => 'MULTIDROP'};
}

=head2 get_current_pop3_access

returns "private", "public" or "publicSSL", depending on whether
the various components of the pop3 subsystem are currently enabled

=cut

sub get_current_pop3_access {
    my $pop3Record = $db->get('popd');
    my $pop3Status = $pop3Record->prop('status') || 'enabled';
    my $pop3Access = $pop3Record->prop('access') || 'private';

    my $pop3sRecord = $db->get('pop3s');
    my $pop3sStatus = $pop3sRecord->prop('status') || 'enabled';
    my $pop3sAccess = $pop3sRecord->prop('access') || 'private';

    if ($pop3Status eq 'enabled' && $pop3Access eq 'public')
    {
        return 'public';
    }
    elsif ($pop3sStatus eq 'enabled' && $pop3sAccess eq 'public')
    {
        return 'publicSSL';
    }
    return 'private';
}

=head2 get_current_imap_access

returns "private", "public" or "publicSSL", depending on whether
the various components of the imap subsystem are currently enabled

=cut

sub get_current_imap_access {
    my $imapRecord = $db->get('imap');
    my $imapStatus = $imapRecord->prop('status') || 'enabled';
    my $imapAccess = $imapRecord->prop('access') || 'private';

    my $imapsRecord = $db->get('imaps');
    my $imapsStatus = $imapsRecord->prop('status') || 'enabled';
    my $imapsAccess = $imapsRecord->prop('access') || 'private';

    if ($imapStatus eq 'enabled' && $imapAccess eq 'public')
    {
        return 'public';
    }
    elsif ($imapsStatus eq 'enabled' && $imapsAccess eq 'public')
    {
        return 'publicSSL';
    }
    return 'private';
}

=head2 get_current_smtp_auth

returns "disabled", "public" or "publicSSL", depending on whether
the various components of the smtp auth subsystem are currently enabled

=cut

sub get_current_smtp_auth {
    my $smtpfront = $db->get('smtpfront-qmail');
    my $smtpStatus = $smtpfront->prop('status') || 'enabled';
    my $smtpAuth = $smtpfront->prop('authentication') || 'disabled';

    my $ssmtpfront = $db->get('ssmtpfront-qmail');
    my $smtpsStatus = $ssmtpfront->prop('status') || 'enabled';
    my $smtpsAuth = $ssmtpfront->prop('authentication') || 'disabled';

    if ($smtpStatus eq 'enabled' && $smtpAuth eq 'enabled')
    {
        return 'public';
    }
    elsif ($smtpsStatus eq 'enabled' && $smtpsAuth eq 'enabled')
    {
        return 'publicSSL';
    }
    return 'disabled';
}

=head2 get_current_webmail_status

returns "disabled", "enabled" or "enabledSSL", depending on whether
the various components of the webmail subsystem are currently enabled

=cut

sub get_current_webmail_status {

  # determine status of webmail
  my $WebmailStatus = "disabled";

  # This is evil and unsafe. Do NOT expect get() to return a valid result!
  # If the record doesn't exist, you are calling methods on undef!
  #my $IMPStatus     = $db->get('imp')->prop("status") || "disabled";
  #my $SSLonly       = $db->get('imp')->prop("access") || "disabled";
  #my $HordeStatus   = $db->get('horde')->prop("status" ) || "disabled";
  #my $MysqlStatus   = $db->get('mysqld')->prop("status" ) || "disabled";
  #my $PHPStatus     = $db->get('php')->prop("status" ) || "disabled";
  
  my $impRecord = $db->get('imp');
  my $IMPStatus = $impRecord->prop('status') || 'disabled';
  my $SSLonly = $impRecord->prop('access') || 'disabled';

  my $hordeRecord = $db->get('horde');
  my $HordeStatus = $hordeRecord->prop('status') || 'disabled';

  my $mysqlRecord = $db->get('mysqld');
  my $MysqlStatus = $mysqlRecord->prop('status') || 'disabled';

  my $phpRecord = $db->get('php');
  my $PHPStatus = $phpRecord->prop('status') || 'disabled';

  # all four components must be on for webmail to be working
  if ( ( $IMPStatus eq "enabled" )
       && ( $HordeStatus eq "enabled" )
       && ( $MysqlStatus eq "enabled" )
       && ( $PHPStatus eq "enabled" ) )
    {
      $WebmailStatus = ( $SSLonly eq "SSL" ) ? "enabledSSL" : "enabled";
    }
  return($WebmailStatus);
  
}

# {{{ Validation

=head1 VALIDATION ROUTINES

=head2 validate_smarthost

Returns OK if smarthost is valid. 

Returns SMARTHOST_VALIDATION_ERROR and pushes us back to the first page otherwise.

=begin testing

ok(validate_smarthost('','foo.com') eq 'OK', 'foo.com is a valid host');
ok(validate_smarthost('','') eq 'OK', 'undef is a valid host');
ok(validate_smarthost('','fleeble') eq 'INVALID_SMARTHOST', '"fleeble" is not a valid host');


=end testing

=cut

sub validate_smarthost {
    my $fm = shift;
    my $smarthost = shift;
    
    return ('OK') if ( $smarthost =~ /^(\S+\.\S+)$/ );

    return ('OK') if ( $smarthost eq '' );
    
    return "INVALID_SMARTHOST";
    
}

=head2 validate_admin_email

This method validates the admin email address.

=cut

sub validate_admin_email
{
    my $self = shift;
    my $q = $self->{cgi};

    my $admin_email = $q->param('AdminEmail') || '';
    $admin_email =~ s/^\s+|\s+$//g;

    my $response = $self->email_simple($admin_email);
    if (($response eq 'OK') or ($admin_email eq ''))
    {
        return 'OK';
    }
    else
    {
        return 'UNACCEPTABLE_CHARS';
    }
}

=pod

=head2 getExtraParams

Returns some extra values for localise() that are used to evaluate embedded
vars in localised text.

=cut

sub getExtraParams
{
	my $conf = esmith::ConfigDB->open();
	my $systemName = $conf->get('SystemName');
	my $domainName = $conf->get('DomainName');

	$systemName = $systemName->value if ($systemName);
	$domainName = $domainName->value if ($domainName);

	return (FQDN => join('.', ($systemName, $domainName)));
}

sub show_mailpatterns_section
{
    my $fm = shift;
    my $q = $fm->cgi;

    my $smtpfront = $db->get('smtpfront-qmail');
    my $ssmtpfront = $db->get('ssmtpfront-qmail');

    return '' unless ($smtpfront->prop('Patterns') eq 'enabled' || $ssmtpfront->prop('Patterns') eq 'enabled');

    my %options;

    my @selected;

    foreach my $pattern ( $pattern_db->get_all_by_prop( type => "pattern" ) )
    {
        my %props = $pattern->props;

        $options{$pattern->key} = $props{'Description'};

        push @selected, $pattern->key if ($props{'Status'} eq 'enabled');
    }

    return $q->Tr(
      $q->td( {-colspan => 2},
      $q->p(
          $q->Tr(
            $q->td({-colspan => 2, -class => "sme-noborders"},
                $fm->localise('DESC_BLOCK_EXECUTABLE_CONTENT'))),
          $q->Tr(
            $q->td({-class => "sme-noborders-label"},
              $fm->localise('LABEL_BLOCK_EXECUTABLE_CONTENT')),
            $q->td({-class => "sme-noborders-content"},
              $q->hidden (-name => 'HaveBlockExeContent', -override => 1, 
                        -default => 'yes'),
              $q->scrolling_list(
                        -name     => 'BlockExecutableContent',
                        -values   => [ sort keys %options ],
                        -labels   => \%options,
                        -size     => 4,
                        -multiple => 'true',
                        -linebreak => 'true',
                        -default  => \@selected,
               )
    ))))); 
}

sub adjust_patterns
{
    my $fm = shift;
    my $q = $fm->{'cgi'};

    my $p = $q->param('HaveBlockExeContent') || 'no';
    return unless ($p eq 'yes');

    my @selected;
    
    push @selected, $q->param('BlockExecutableContent');

    foreach my $pattern ( $pattern_db->get_all_by_prop( type => "pattern") )
    {
        my $status = (grep $pattern->key eq $_, @selected) ? 'enabled' 
                                                           : 'disabled';
        $pattern->set_prop('Status', $status);
    }

    $pattern_db->reload;
}

1;

